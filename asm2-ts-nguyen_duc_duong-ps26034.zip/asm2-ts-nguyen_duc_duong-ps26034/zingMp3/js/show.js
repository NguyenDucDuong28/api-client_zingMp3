
const navbarItems = Array.from(document.querySelectorAll('.zm-navbar-item-is-active'));


// Lưu trạng thái khi nhấp vào phần tử
navbarItems.forEach(item => {
  item.addEventListener('click', function() {
    const itemId = this.getAttribute('data-item-id');
    localStorage.setItem('activeItemId', itemId);
  });
});

// Kiểm tra trạng thái và áp dụng lại khi trang được tải lại
window.addEventListener('DOMContentLoaded', function() {
  const activeItemId = localStorage.getItem('activeItemId');
  if (activeItemId) {
    const activeItem = navbarItems.find(item => item.getAttribute('data-item-id') === activeItemId);
    activeItem.classList.add('active');
  }
});


//


const navbarLibrary= Array.from(document.querySelectorAll('.zm-navbar-item-is-library'));


// Lưu trạng thái khi nhấp vào phần tử
navbarLibrary.forEach(item => {
  item.addEventListener('click', function() {
    const itemId = this.getAttribute('data-item-id');
    localStorage.setItem('activeItemId', itemId);
  });
});

// Kiểm tra trạng thái và áp dụng lại khi trang được tải lại
window.addEventListener('DOMContentLoaded', function() {
  const activeItemId = localStorage.getItem('activeItemId');
  if (activeItemId) {
    const activeItem = navbarLibrary.find(item => item.getAttribute('data-item-id') === activeItemId);
    activeItem.classList.add('active');
  }
});

//
const navbarBXH= Array.from(document.querySelectorAll('.zm-sidebar-scrollbar-BXH'));


// Lưu trạng thái khi nhấp vào phần tử
navbarBXH.forEach(item => {
  item.addEventListener('click', function() {
    const itemId = this.getAttribute('data-item-id');
    localStorage.setItem('activeItemId', itemId);
  });
});

// Kiểm tra trạng thái và áp dụng lại khi trang được tải lại
window.addEventListener('DOMContentLoaded', function() {
  const activeItemId = localStorage.getItem('activeItemId');
  if (activeItemId) {
    const activeItem = navbarBXH.find(item => item.getAttribute('data-item-id') === activeItemId);
    activeItem.classList.add('active');
  }
});


const songLinks = document.querySelectorAll(".song-link");
songLinks.forEach((link) => {
  link.addEventListener("click", async function (event) {
    
    event.preventDefault(); // Ngăn chặn hành động mặc định của link
    const playIcon = link.querySelector(".play-icon");
    const playinIcon = link.querySelector(".playin-icon");

        // Kiểm tra trạng thái hiển thị của playIcon và playinIcon
        if (playIcon.style.display !== "none") {
          
            playIcon.style.display = "none";
            playinIcon.style.display = "block";
        } else {
            playIcon.style.display = "block";
            playinIcon.style.display = "none";
        }
  }
)});




const apiSong = "http://localhost:3030/song";
const showSong  = document.querySelector(".list");
const form = document.querySelector(".form");

// Load the page

const data = async () => {
  const res = await fetch(apiSong);
  const data = await res.json();
  console.log(data);
  return data;
};

const row = (item) => {
  const template = `
  <div class="list-music">
  <div class="list-row">
      <div class="media">
          <div class="media-left">
              <div class="song-thumb">
                  <div
                      class="song-thumb-img">
                      <a href="#"
                          class="song-link">
                          <img
                              src="${item.image}"
                              alt>
                          <div
                              class="play-icon ">
                              <i
                                  class="ri-play-fill"></i>
                          </div>
                          <div
                              class="playin-icon ">
                              <img
                                  style=" border-radius: 0px;"
                                  src="../img/icon/icon-playing.gif"
                                  alt>
                          </div>
                      </a>
                  </div>
              </div>
              <div class="card-info">
                  <div
                      class="card-info-name_music">
                      <span>${item.name}</span>
                  </div>
                  <div class="info-artist">
                      <div
                          class="card-info-artist">
                          <span>${item.author}</span>
                      </div>
                  </div>
                  <div
                      class="card-info-day">
                      <span>${item.timesTamp}</span>
                  </div>
              </div>
          </div>
          <div class="media-right">
              <i class="ri-more-line"></i>
          </div>
      </div>
  </div>
</div>
    `;
  if (showSong) {
    showSong.insertAdjacentHTML("beforeend", template);
  }
};

const renderSong = async () => {
  const listSong = await data();
  if (Array.isArray(listSong) && listSong.length > 0) {
    listSong.forEach((song) => {
      row(song);
    });
  }
};

renderSong();
