const apiUser = "http://localhost:3030/users";

function redirectToManageSongPage() {
  window.location.href = "/view/login.html";
}

const formPost = document.querySelector(".signup-form");

// chuyền dữ liệu nhập vào db.json
async function addNewUser({ name, email, password }) {
  await fetch(apiUser, {
    method: "POST",
    body: JSON.stringify({
      name,
      password,
      email,
    }),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  });
}

async function checkEmailExistence(email) {
  const response = await fetch(apiUser + `?email=${encodeURIComponent(email)}`);
  const data = await response.json();
  return data.length > 0; // Return true if email exists, false otherwise
}

formPost.addEventListener("submit", async function (e) {
  e.preventDefault();
  const name = this.elements["name"].value;
  const email = this.elements["email"].value;
  const password = this.elements["password"].value;

  const emailExists = await checkEmailExistence(email);
  
  if (emailExists) {
    alert("Email Này Đã tồi tại vui lòng nhập email mới");
  } else {
    await addNewUser({ name, email, password });
    redirectToManageSongPage();
  }
});
