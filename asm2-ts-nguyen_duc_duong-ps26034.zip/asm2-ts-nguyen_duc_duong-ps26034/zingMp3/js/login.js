document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("login").addEventListener("click", function (event) {
    event.preventDefault();

    function login() {
      window.location.href = "/view/index.html";
  }
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Gửi mật khẩu chưa mã hóa lên máy chủ để kiểm tra
    fetch("http://localhost:3030/users/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: email,
        password: password, // Mật khẩu chưa mã hóa
      }),
    })
    .then(function (response) {
      return response.json();
    })
    .then(function (loginData) {
      console.log(loginData);
      if (loginData.user) {
        console.log("đăng thành");
         login()// Chuyển hướng khi đăng nhập thành công
      } else {
        alert(loginData.error); // Hiển thị thông báo lỗi khi đăng nhập sai
      }
    })
    .catch(function (error) {
      console.log("Đã xảy ra lỗi khi đăng nhập: " + error);
    });
  });
});
