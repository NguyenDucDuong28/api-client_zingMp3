
const apiBXH = "http://localhost:3030/song";
const showBXH = document.querySelector(".content");


// Load the page

const dataBXH = async () => {
  const res = await fetch(apiBXH);
  const dataBXH = await res.json();
  console.log(dataBXH);
  return dataBXH;
};

const row = (item) => {
  const list = `
  <div class="content-central">
  <div class="chart-song">
      <div class="chart-song-right">
          <div class="chart-song-stt">
              <span>1</span>
          </div>
          <div class="chart-song-icon">
              <i class="ri-arrow-right-circle-line"></i>
          </div>
          <div class="chart-song-img">
              <img src="${item.image}" alt="">
          </div>
          <div class="chart-song-name">
              <div class="chart-song-name_song">
                  <p>${item.name}</p>
              </div>
              <div class="chart-song-composed">
                  <p>${item.author}</p>
              </div>
          </div>
      </div>
          <div class="chart-song-central">
              <p>${item.name}</p>
          </div>
          <div class="chart-song-left">
              <div class="chart-song-left-time">
                  <p>0:40</p>
              </div>
          </div>    
  </div>
</div>
    `;
  if (showBXH) {
    showBXH.insertAdjacentHTML("beforeend", list);
  }
};

const renderSong = async () => {
  const listBXH = await dataBXH();
  if (Array.isArray(listBXH) && listBXH.length > 0) {
    listBXH.forEach((song) => {
      row(song);
    });
  }
};

renderSong();
