const listUser: string = "http://localhost:3030/users";
const cardList: HTMLElement | null = document.querySelector(".list-user");
let sttt: number = 0;

interface User {
  _id: string;
  name: string;
  email: string;
  password: string;
}

async function randerItem(item: User, stt: number): Promise<void> {
  const template: string = `<tr>
    <td>${stt}</td>
    <td>${item.name}</td>
    <td>${item.email}</td>
    <td style="width: 70px">${item.password}</td>
    <td>
      <a class="btn-edit" href="/products/cpanel/edit/${item._id}">Sửa</a>
      <a class="btn-delete" href="/products/cpanel/delete/${item._id}">Xóa</a>
    </td>
  </tr>`;
  if (cardList) {
    cardList.insertAdjacentHTML("beforeend", template);
  }
  console.log(template);
}

async function getShirt(): Promise<void> {
  const response = await fetch(listUser);
  const data = await response.json();
  if (cardList) {
    cardList.innerHTML = "";
  }
  if (data.length > 0 && Array.isArray(data)) {
    data.forEach((item: User) => {
      sttt += 1;
      randerItem(item, sttt);
    });
  }
  console.log(data);
}

getShirt();
