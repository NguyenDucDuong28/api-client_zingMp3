// import axios from "axios";
const endpoint = "http://localhost:3030/song";
const tableBody : HTMLTableSectionElement | null = document.querySelector(".list_product");
const form = document.querySelector(".form") as HTMLFormElement;
let stt = 0;
const targetUrl = "/adminhub-master/view/manege_song.html";
  
// Load the page

interface SongData {
  _id: string;
  name: string;
  author: string;
  image: string;
  timesTamp: string;
  album: string;
}

const data = async () => {
  const res = await fetch(endpoint);
  const data = await res.json();
  console.log(data)
  return data;
};
data()

const row = (item: SongData, stt: Number) => {
  const template = `
  <tr>
  <td class="id">${stt}</td>
  <td class="product-img"><img src="${item.image}" alt="${item.name}" /></td>
  <td class="product-name">${item.name}</td>
  <td class="product-author">${item.author}</td>
  <td class="product-album">${item.album}</td>
  <td class="product-album">${item.timesTamp}</td>
  <td>
    <div class="product-actions">
      <button class="add">Add</button>
      <button class="delete" data-id="${item._id}">Delete</button>
      <a href="../view/edit.html?id=${item._id}">
        <button class="edit" data-id="${item._id}">Edit</button>
      </a>
    </div>    
  </td>
</tr>
    `;
  tableBody?.insertAdjacentHTML("beforeend", template);
};

const renderSong = async () => {
  const listSong = await data();
  if (listSong.length > 0 && Array.isArray(listSong)) {
    listSong.map((song) => {
      stt++;
      row(song, stt);
    });
  }
};





async function deleteShirt(id: string) {
  try {
    await fetch(`${endpoint}/${id}`, {
      method: "DELETE",
    });
  } catch (error) {
    console.error("Error deleting shirt:", error);
  }
}

if (tableBody !== null) {
  tableBody.addEventListener("click", async (event) => {
    const target = event.target as HTMLElement;
    if (target.classList.contains("delete")) {
      const songId = target.dataset.id;
      if (songId) {
        try {
          await deleteShirt(songId);
          // After successful deletion, remove the row from the UI
          const rowToDelete = target.closest("tr");
          if (rowToDelete) {
            const isConfirmed = confirm("Bạn có chắc chắn xóa không?");
            window.location.href = targetUrl;
            if (isConfirmed) {
              rowToDelete.remove();
            }
          }
        } catch (error) {
          console.error("Error deleting shirt:", error);
        }
      } else {
        console.error('Product ID not found.');
      }
    }
  });
}
renderSong();
