"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const listUser = "http://localhost:3030/users";
const cardList = document.querySelector(".list-user");
let sttt = 0;
function randerItem(item, stt) {
    return __awaiter(this, void 0, void 0, function* () {
        const template = `<tr>
    <td>${stt}</td>
    <td>${item.name}</td>
    <td>${item.email}</td>
    <td style="width: 70px">${item.password}</td>
    <td>
      <a class="btn-edit" href="/products/cpanel/edit/${item._id}">Sửa</a>
      <a class="btn-delete" href="/products/cpanel/delete/${item._id}">Xóa</a>
    </td>
  </tr>`;
        if (cardList) {
            cardList.insertAdjacentHTML("beforeend", template);
        }
        console.log(template);
    });
}
function getShirt() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(listUser);
        const data = yield response.json();
        if (cardList) {
            cardList.innerHTML = "";
        }
        if (data.length > 0 && Array.isArray(data)) {
            data.forEach((item) => {
                sttt += 1;
                randerItem(item, sttt);
            });
        }
        console.log(data);
    });
}
getShirt();
