const endpointShop = "http://localhost:3030/song/:id";
console.log(endpointShop);

// Lấy thông tin sản phẩm từ URL
const urlParams = new URLSearchParams(window.location.search);
const songId = urlParams.get("id");


// Lấy form và các trường thông tin sản phẩm
const form = document.querySelector(".form-put");
const nameInput = document.getElementById("name");
const authorInput = document.getElementById("author");
const timesTampInput = document.getElementById("timesTamp");
const imageInput = document.getElementById("image");
const albumInput = document.getElementById("album");

// Gửi request để lấy thông tin sản phẩm từ API
fetch(`${endpointShop}/${songId}`)
  .then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    return response.json();
  })
  .then((song) => {
    // Điền thông tin sản phẩm vào form
    nameInput.value = song.name;
    authorInput.value = song.author;
    timesTampInput.value = song.timesTamp;
    imageInput.value = song.image;
    albumInput.value = song.album;
  })
  .catch((error) => {
    console.error("Lỗi khi lấy thông tin sản phẩm:", error);
    // Handle the error here, e.g., show an error message to the user
  });

// Xử lý sự kiện khi submit form
form.addEventListener("submit", (event) => {
  event.preventDefault(); // Ngăn chặn form gửi dữ liệu đi

  // Lấy giá trị từ các trường thông tin sản phẩm trong form
  const name = nameInput.value;
  const author = authorInput.value;
  const timesTamp = timesTampInput.value;
  const image = imageInput.value;
  const album = albumInput.value;

  // Gửi request cập nhật dữ liệu sản phẩm lên API
  fetch(`${endpointShop}/${songId}`, {
    method: "PUT", // Assuming you use the PUT method to update data
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      name,
      author,
      timesTamp,
      image,
      album,
    }),
  })
    .then((response) => {
      if (response.ok) {
        alert("Cập nhật sản phẩm thành công");
      } else {
        alert("Cập nhật sản phẩm thất bại");
      }
    })
    .catch((error) => {
      console.error("Lỗi khi cập nhật sản phẩm:", error);
      // Handle the error here, e.g., show an error message to the user
    });
    window.location.href = "../view/manege_song.html";
  });