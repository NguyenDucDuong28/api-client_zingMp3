"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// import axios from "axios";
const endpoint = "http://localhost:3030/song";
const tableBody = document.querySelector(".list_product");
const form = document.querySelector(".form");
let stt = 0;
const targetUrl = "/adminhub-master/view/manege_song.html";
const data = () => __awaiter(void 0, void 0, void 0, function* () {
    const res = yield fetch(endpoint);
    const data = yield res.json();
    console.log(data);
    return data;
});
data();
const row = (item, stt) => {
    const template = `
  <tr>
  <td class="id">${stt}</td>
  <td class="product-img"><img src="${item.image}" alt="${item.name}" /></td>
  <td class="product-name">${item.name}</td>
  <td class="product-author">${item.author}</td>
  <td class="product-album">${item.album}</td>
  <td class="product-album">${item.timesTamp}</td>
  <td>
    <div class="product-actions">
      <button class="add">Add</button>
      <button class="delete" data-id="${item._id}">Delete</button>
      <a href="../view/edit.html?id=${item._id}">
        <button class="edit" data-id="${item._id}">Edit</button>
      </a>
    </div>    
  </td>
</tr>
    `;
    tableBody === null || tableBody === void 0 ? void 0 : tableBody.insertAdjacentHTML("beforeend", template);
};
const renderSong = () => __awaiter(void 0, void 0, void 0, function* () {
    const listSong = yield data();
    if (listSong.length > 0 && Array.isArray(listSong)) {
        listSong.map((song) => {
            stt++;
            row(song, stt);
        });
    }
});
function deleteShirt(id) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield fetch(`${endpoint}/${id}`, {
                method: "DELETE",
            });
        }
        catch (error) {
            console.error("Error deleting shirt:", error);
        }
    });
}
if (tableBody !== null) {
    tableBody.addEventListener("click", (event) => __awaiter(void 0, void 0, void 0, function* () {
        const target = event.target;
        if (target.classList.contains("delete")) {
            const songId = target.dataset.id;
            if (songId) {
                try {
                    yield deleteShirt(songId);
                    // After successful deletion, remove the row from the UI
                    const rowToDelete = target.closest("tr");
                    if (rowToDelete) {
                        const isConfirmed = confirm("Bạn có chắc chắn xóa không?");
                        window.location.href = targetUrl;
                        if (isConfirmed) {
                            rowToDelete.remove();
                        }
                    }
                }
                catch (error) {
                    console.error("Error deleting shirt:", error);
                }
            }
            else {
                console.error('Product ID not found.');
            }
        }
    }));
}
renderSong();
