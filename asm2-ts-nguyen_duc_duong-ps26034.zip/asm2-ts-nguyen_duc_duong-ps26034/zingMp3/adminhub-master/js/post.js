"use strict";
var _a;
const listAlbum = document.querySelector('.list-album');
const apiSong = "http://localhost:3030/song";
function redirectToManageSongPage() {
    window.location.href = "/adminhub-master/view/manege_song.html";
}
(_a = document.getElementById("addSongForm")) === null || _a === void 0 ? void 0 : _a.addEventListener("submit", function (event) {
    event.preventDefault(); // Ngăn form gửi dữ liệu một cách thông thường
    // Lấy dữ liệu từ form
    const formData = new FormData(this);
    // Gửi dữ liệu lên server bằng Ajax
    const xhr = new XMLHttpRequest();
    xhr.open("POST", apiSong, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Xử lý phản hồi từ server nếu cần thiết
                console.log(xhr.responseText);
                alert("Dữ liệu đã được gửi lên server thành công!");
            }
            else {
                // Xử lý lỗi nếu có
                console.error("Đã xảy ra lỗi khi gửi dữ liệu lên server.");
            }
        }
    };
    xhr.send(formData);
    redirectToManageSongPage();
});
